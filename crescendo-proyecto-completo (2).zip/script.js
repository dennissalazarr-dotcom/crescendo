// Funciones simples de la tienda.
function mostrarMensaje() {
  alert('¡Gracias por tu interés! Elige un producto o escríbenos desde la sección de contacto.');
}

function agregarCarrito(nombre) {
  alert('Agregaste "' + nombre + '" al carrito.');
}
