<?php
// Datos de conexión a la base de datos (Hostinger).
// IMPORTANTE: escribe tu contraseña aquí. Este archivo NO se sube a GitHub (.gitignore).
return [
    'host'    => 'localhost',
    'base'    => 'u157738937_music',
    'usuario' => 'u157738937_sebastian',
    'clave'   => 'ESCRIBE_AQUI_TU_CONTRASENA',
];
